1.Use the data file in this folder. It just contains change in name and format.
2.Generation of p values takes some time~1.4 minutes.